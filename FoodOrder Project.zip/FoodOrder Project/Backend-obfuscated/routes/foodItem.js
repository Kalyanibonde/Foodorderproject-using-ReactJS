const _0xc51e19 = _0x4311;
function _0x4311(_0x41bdfd, _0x349362) {
  const _0x436598 = _0x4365();
  return (
    (_0x4311 = function (_0x43119b, _0x4464bf) {
      _0x43119b = _0x43119b - 0xf8;
      let _0x3455b5 = _0x436598[_0x43119b];
      return _0x3455b5;
    }),
    _0x4311(_0x41bdfd, _0x349362)
  );
}
(function (_0x726066, _0x1200bf) {
  const _0x287ff8 = _0x4311,
    _0x52f791 = _0x726066();
  while (!![]) {
    try {
      const _0x47fe45 =
        parseInt(_0x287ff8(0x108)) / 0x1 +
        (parseInt(_0x287ff8(0x107)) / 0x2) * (parseInt(_0x287ff8(0xfe)) / 0x3) +
        (-parseInt(_0x287ff8(0xff)) / 0x4) *
          (parseInt(_0x287ff8(0x105)) / 0x5) +
        parseInt(_0x287ff8(0x101)) / 0x6 +
        (parseInt(_0x287ff8(0x102)) / 0x7) *
          (-parseInt(_0x287ff8(0x10a)) / 0x8) +
        (-parseInt(_0x287ff8(0x104)) / 0x9) *
          (-parseInt(_0x287ff8(0xfc)) / 0xa) +
        -parseInt(_0x287ff8(0x10b)) / 0xb;
      if (_0x47fe45 === _0x1200bf) break;
      else _0x52f791["push"](_0x52f791["shift"]());
    } catch (_0x11c132) {
      _0x52f791["push"](_0x52f791["shift"]());
    }
  }
})(_0x4365, 0x67c8a);
const express = require("express"),
  router = express[_0xc51e19(0xf8)]({ mergeParams: !![] }),
  {
    getFoodItem,
    createFoodItem,
    getAllFoodItems,
    deleteFoodItem,
    updateFoodItem,
  } = require(_0xc51e19(0x100));
router[_0xc51e19(0x103)]("/item")[_0xc51e19(0xf9)](createFoodItem),
  router[_0xc51e19(0x103)](_0xc51e19(0x106))["get"](getAllFoodItems),
  router[_0xc51e19(0x103)](_0xc51e19(0xfa))
    [_0xc51e19(0xfd)](getFoodItem)
    [_0xc51e19(0xfb)](updateFoodItem)
    [_0xc51e19(0x109)](deleteFoodItem),
  (module["exports"] = router);
function _0x4365() {
  const _0x24653e = [
    "Router",
    "post",
    "/item/:foodId",
    "patch",
    "1714340pvieCz",
    "get",
    "505347EYciZW",
    "268UHWNPn",
    "../controllers/foodItemController",
    "723768UBIstO",
    "7HVeyEO",
    "route",
    "27WQDEaT",
    "56085UtkuxM",
    "/items/:storeId",
    "10mXdkUw",
    "460820WPmxIT",
    "delete",
    "5106256eNZRpA",
    "1353836xqAKBV",
  ];
  _0x4365 = function () {
    return _0x24653e;
  };
  return _0x4365();
}
