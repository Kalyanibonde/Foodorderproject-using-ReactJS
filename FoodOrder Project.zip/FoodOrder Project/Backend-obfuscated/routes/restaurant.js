const _0x4185a9 = _0x4828;
function _0x4828(_0x154797, _0x2ce519) {
  const _0x316949 = _0x3169();
  return (
    (_0x4828 = function (_0x482818, _0x4e07de) {
      _0x482818 = _0x482818 - 0x1af;
      let _0x1e86d9 = _0x316949[_0x482818];
      return _0x1e86d9;
    }),
    _0x4828(_0x154797, _0x2ce519)
  );
}
(function (_0x891f, _0x3a05db) {
  const _0x15db93 = _0x4828,
    _0x57ae67 = _0x891f();
  while (!![]) {
    try {
      const _0x19e017 =
        -parseInt(_0x15db93(0x1b4)) / 0x1 +
        parseInt(_0x15db93(0x1b8)) / 0x2 +
        parseInt(_0x15db93(0x1b5)) / 0x3 +
        (-parseInt(_0x15db93(0x1b7)) / 0x4) *
          (-parseInt(_0x15db93(0x1af)) / 0x5) +
        -parseInt(_0x15db93(0x1c2)) / 0x6 +
        (parseInt(_0x15db93(0x1b3)) / 0x7) *
          (parseInt(_0x15db93(0x1c1)) / 0x8) +
        (-parseInt(_0x15db93(0x1ba)) / 0x9) *
          (parseInt(_0x15db93(0x1b2)) / 0xa);
      if (_0x19e017 === _0x3a05db) break;
      else _0x57ae67["push"](_0x57ae67["shift"]());
    } catch (_0x1457e1) {
      _0x57ae67["push"](_0x57ae67["shift"]());
    }
  }
})(_0x3169, 0x4e6d0);
const express = require("express"),
  router = express[_0x4185a9(0x1b0)]({ mergeParams: !![] }),
  {
    getAllRestaurants,
    createRestaurant,
    getRestaurant,
    deleteRestaurant,
  } = require(_0x4185a9(0x1c0)),
  menuRoutes = require(_0x4185a9(0x1be));
router[_0x4185a9(0x1b6)]("/")
  [_0x4185a9(0x1bf)](getAllRestaurants)
  ["post"](createRestaurant),
  router[_0x4185a9(0x1b6)](_0x4185a9(0x1bc))
    ["get"](getRestaurant)
    [_0x4185a9(0x1bd)](deleteRestaurant),
  router[_0x4185a9(0x1bb)](_0x4185a9(0x1b9), menuRoutes),
  (module[_0x4185a9(0x1b1)] = router);
function _0x3169() {
  const _0x193a60 = [
    "170aCFJRF",
    "421988YHoVhG",
    "165174lakIpu",
    "1536978idfiEE",
    "route",
    "4rafvAj",
    "711024EGIYCu",
    "/:storeId/menus",
    "364203YEgdPG",
    "use",
    "/:storeId",
    "delete",
    "./menu",
    "get",
    "../controllers/restaurantController",
    "48FrDxob",
    "1352856NjCsKK",
    "851395dsokSC",
    "Router",
    "exports",
  ];
  _0x3169 = function () {
    return _0x193a60;
  };
  return _0x3169();
}
