import React from 'react'
import { FaRupeeSign } from "react-icons/fa";
export default function FoodItem() {
  return (
   <div className="col-sm-12 col-md-6 col-lg-3 my-3">
       <div className="card p-3 rounded">
        <img src="https://b.zmtcdn.com/data/pictures/chains/6/10506/1adb116d088669540c89150836d668f9.jpg?fit=around|960:500&crop=960:500;*,*"
         alt="Pizza" 
         className='card-img-top mx-auto'/>
           <div className="card-body d-flex flex-column">
            <h5 className="card-title">
                Veg Loaded Pizza
            </h5>
            <p className="fooditem_des">
            Crunchy Brunchy And Chinese Pizza served with Happiness
            </p>
            <p className="card-text">
            <FaRupeeSign />180
            <br/>
            </p>
            <button className="btn btn-primary d-inline ml-4" type="button" id="cart_btn">
                Add to Cart
            </button>
            <p>Status: <span id="stock_status" className={10>5?"greenColor":"redColor"}>{10>5?"In stock":"Out of stock"}</span></p>
           </div>
       </div>
   </div>
  )
}
