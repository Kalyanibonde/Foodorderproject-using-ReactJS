import React from 'react'

export default function Restaurant() {
  return (
    
      <div className="col-sm-12 col-md-6 col-lg-3 my-3">
        <div className="card p-3 rounded">
            <img src="https://images.dominos.co.in/nextgen-catalog/media/prod/Dominos/menu/79bc3609-690b-440e-b8be-74694b1f3215_new_margherita_2502.jpg"
               alt="Dominos"/>

            <div className="card-body d-flex flex-column">
                <h5 className="card-tittle">Dominos Pizza</h5>
                <p className="rest_address">123 Street, place , City-000000, State</p>
              <div className="rating-outer">
                <div className="rating-inner"></div>
                    <span id="no_of_reviews">(140 Reviews)</span>
                
               </div>
            </div>
         </div>
      </div>

  )
}
