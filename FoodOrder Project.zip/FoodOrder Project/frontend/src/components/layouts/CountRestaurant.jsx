import React from 'react'

export default function CountRestaurant() {
  return (
    <div>
      <p className="NumOfRestro">8
        <span className="Restro"> Restaurants</span>
      </p>
      <hr/>
    </div>
  )
}
